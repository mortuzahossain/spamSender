package com.wordpress.mortuzabaust.spamsender;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.format.Formatter;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    EditText from, to, sub, mes, num;
    Button send;
    String _from, _to, _sub, _mes, _num, ipAddress;
    String url = "https://userfun.000webhostapp.com/spamsender/api.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Declaring the input and Button
        from = (EditText) findViewById(R.id.fromAddress);
        to = (EditText) findViewById(R.id.toAddress);
        sub = (EditText) findViewById(R.id.subject);
        mes = (EditText) findViewById(R.id.message);
        num = (EditText) findViewById(R.id.sendNumber);
        send = (Button) findViewById(R.id.send);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Taking Input
                _from = from.getText().toString();
                _to = to.getText().toString();
                _sub = sub.getText().toString();
                _mes = mes.getText().toString();
                _num = num.getText().toString();

                // Finding The IP address

                WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
                ipAddress = Formatter.formatIpAddress(wifiManager.getConnectionInfo().getIpAddress());

                if (_from.isEmpty() || _to.isEmpty() || _sub.isEmpty() || _mes.isEmpty() || _num.isEmpty()) {
                    invalid_input();
                } else {
                    if (!isValidEmail(_from) || !isValidEmail(_to) && !isConnectingToInternet(MainActivity.this)) {
                        invalid_email();
                    } else {
                        StringRequest sq = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                VolleyLog.d("Connected");
                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                            }
                        }) {
                            protected Map<String, String> getParams() {
                                Map<String, String> parr = new HashMap<String, String>();

                                parr.put("fromemail", _from);
                                parr.put("email", _to);
                                parr.put("sub", _sub);
                                parr.put("message", _mes);
                                parr.put("loop", _num);
                                parr.put("ip", ipAddress);

                                return parr;

                            }

                        };

                        AppController.getInstance().addToRequestQueue(sq);
                        // Showing Done Dialog
                        done_dialog();
                        // Clear All The Value
                        from.setText("");
                        to.setText("");
                        sub.setText("");
                        mes.setText("");
                        num.setText("");
                    }
                }
            }
        });

    }


    //Aleart diaglog invalid input
    public void invalid_input() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(Html.fromHtml("<font color = '#ff2a00'>Warning !!!</font>"));
        builder.setMessage("Please fill all  input field.");
        builder.setNegativeButton("OK", null);
        AlertDialog alert = builder.create();
        alert.show();
    }

    //Aleart diaglog invalid input
    public void invalid_email() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(Html.fromHtml("<font color = '#ff2a00'>Warning !!!</font>"));
        builder.setMessage("Invalid Email Address.");
        builder.setNegativeButton("OK", null);
        AlertDialog alert = builder.create();
        alert.show();
    }

    // validating email id
    private boolean isValidEmail(String email) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    // check internet connection
    public static boolean isConnectingToInternet(Context context) {
        ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++) {
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
                }
        }
        return false;
    }

    // Done Sending Dialog
    public void done_dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Done Sending");
        builder.setMessage("Email Send Almost Complete. We are sending your Mail .You Have to wait for sometime .Don't worry ..");
        builder.setNegativeButton("OK", null);
        AlertDialog alert = builder.create();
        alert.show();
    }

    // Back Button Press Alert Dialog
    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(Html.fromHtml("<font color = '#ff2a00'>Warning !!!</font>"));
        builder.setMessage("Are you sure want to Exit ??");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setNegativeButton("NO", null);
        AlertDialog alert = builder.create();
        alert.show();
    }

    // Developer Alert Diaglog
    public void devAlert() {
        AlertDialog.Builder builder_about = new AlertDialog.Builder(this);
        builder_about.setTitle("About Developer");
        builder_about.setMessage("This App ss Developed by Md. Mortuza Hossain\n\nFor More Detail and Contuct with me");
        builder_about.setIcon(R.drawable.about);
        builder_about.setPositiveButton("Facebook", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                //url of my facebook account
                intent.setData(Uri.parse("https://web.facebook.com/mdmortuza.hossain"));
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });
        builder_about.setNegativeButton("Cancel", null);
        AlertDialog alert_about = builder_about.create();
        alert_about.show();
    }

    // Tearm And Condition Alert Diaglog
    public void tearmDiag() {
        AlertDialog.Builder builder_about = new AlertDialog.Builder(this);
        builder_about.setTitle("Term And Condition:");
        builder_about.setMessage("PLEASE Do Not Harm Anybody.\n1. It might Get Some Info Of you." +
                "\n2. It can hunt you local IP address." +
                "\n3. If you make harm to anybody by this app then the author will not be guilty." +
                "\n4. If any threat come to author then he can provide your IP address to government." +
                "\n5. Please use it for fun." +
                "\n6. Initially I am not recording any information."
        );
        builder_about.setIcon(R.drawable.about);
        builder_about.setNegativeButton("Cancel", null);
        AlertDialog alert_about = builder_about.create();
        alert_about.show();
    }

    // Developer Alert Diaglog
    public void helpDiag() {
        AlertDialog.Builder builder_about = new AlertDialog.Builder(this);
        builder_about.setTitle("HELP");
        builder_about.setMessage("1. TO USE THIS APP YOU MUST HAVE TO CONNECT YOUR DEVICE WITH INTERNET.\n2. THEN FILL THE GIVEN FORM WITH VALID INFORMATION.\n3. THEN HIT THE START SENDING BUTTON\n\nAND YOU ARE DONE...\n\nHAPPY SPAM SENDING");
        builder_about.setIcon(R.drawable.about);
        builder_about.setPositiveButton("CONTACT ME", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                //url of my facebook account
                intent.setData(Uri.parse("https://web.facebook.com/mdmortuza.hossain"));
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });
        builder_about.setNegativeButton("Cancel", null);
        AlertDialog alert_about = builder_about.create();
        alert_about.show();
    }

    // open website
    public void webSite(String open) {
        Intent moreapp = new Intent(Intent.ACTION_VIEW);
        String moreapp_url = open;
        moreapp.setData(Uri.parse(moreapp_url));
        if (moreapp.resolveActivity(getPackageManager()) != null) {
            startActivity(moreapp);
        }
    }

    // For Menu Bar

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.more_app) {
            String webUrl = "https://appbajar.com/bn/profile/mortuzahossain1997/apps";
            webSite(webUrl);
            return true;
        }
        if (id == R.id.about) {
            devAlert();
            return true;
        }
        //open alert dialog help
        if (id == R.id.help) {
            helpDiag();
            return true;
        }
        // open main erbsite
        if (id == R.id.mainWebsite) {
            String webUrl = "https://userfun.000webhostapp.com/spamsender/";
            webSite(webUrl);
            return true;
        }
        // open tearm page in the web
        if (id == R.id.tearm) {
            tearmDiag();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


}
